//codice del server :
#include <netinet/in.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
//definisco delle costanti:
#define SERVER_PORT 9002       			// numero di porta del server
#define SOCKET_ERROR  ((int)-1)  		// codice di errore
#define MAX_CONNECTION 10		//numero massimo delle connessioni accettate
#define BUFFER_LENGTH 80
//prototipi funzione
void reverse(int);
/*
	Note : non termina correttamente il processo lato client.
	Altri test tutti ok.
*/
int main () {
	int newsocket, client_len, wsocket,pid;
	struct sockaddr_in servizio,cliente;  //indirizzi del server  e del client
	int cont=0;

	printf ("socket()\n");
	if((newsocket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("chiamata alla system call socket fallita");
		return(1);
	}

	servizio.sin_family = AF_INET;
	servizio.sin_addr.s_addr = htonl(INADDR_ANY);
	servizio.sin_port = htons(SERVER_PORT);

	/* leghiamo l'indirizzo al transport endpoint */
	printf ("bind()\n");
	if (bind(newsocket, (struct sockaddr *)&servizio, sizeof servizio) == -1)
	{
		perror("chiamata alla system call bind fallita.\n");
		return(2);
	}

	/* poniamo il server in ascolto delle richieste dei client */
	printf ("listen()\n");
	listen(newsocket, MAX_CONNECTION);		//coda massima di 10 elementi

	/* gestione delle connessioni dei client */
	printf ("accept()\n");
	while (1) {
		if(cont<MAX_CONNECTION){
			cont++;
			client_len = sizeof(cliente);
			if ((wsocket = accept(newsocket, (struct sockaddr *)&cliente, &client_len)) < 0)
			{
				perror("Connessione non accettata");
				return(3);
			}
			if((pid=fork()) <0){	//creo il processo figlio
				perror("Errore nella creazione del nuovo processo.\n");
				exit(1);
			}
			else if(pid == 0){
				fprintf(stderr, "Aperta connessione col server.\n");  	// echo nel client
				fprintf(stderr, "In esecuzione processo.\n");
				reverse(wsocket);						//funzione che svolge effettivamente il codice
				close(wsocket);
				fprintf(stderr, "Chiusa connessione col server.\n");  	// echo nel client
				exit(1);
			}
		}
		else{
			printf("Un utente ha tentato di connettersi senza successo.\n");
		}
	}
}


void reverse(int fd){
	/*
		Con una stringa inviata via socket la funzione strlen darà come ritorno
		sempre una lunghezza maggiore di due rispetto a quella effettiva.
	*/
	char msg[BUFFER_LENGTH];
	char parola[BUFFER_LENGTH];
	char rovescio[BUFFER_LENGTH];
	int i=0,j=0;

	sprintf(msg,"Benvenuto in reverse string.\n");
	send(fd,msg,strlen(msg),0);

	sprintf(msg,"Inserisci stringa : ");
	send(fd,msg,strlen(msg),0);

	recv(fd,parola,BUFFER_LENGTH,0);
	//stampa di prova :
	printf("Ho ricevuto la parola : %s\n",parola);
	printf("Lunghezza stringa ricevuta : %d.\n",(int)strlen(parola)-2);
	//inverto la parola
	j=strlen(parola)-3;
	printf("Valore di j : %d.\n",j);
	for(i=0;i<=strlen(parola)-3;i++){
		rovescio[i]=parola[j];
		j--;
	}
	//stampa nel client
	printf("La stringa rovesciata e' : %s.\n",rovescio);
	//concateno la stringa e la invio nel socket
	sprintf(msg,"La stringa rovesciata e' : %s.\n",rovescio);
	send(fd,msg,strlen(msg),0);
	sprintf(msg,"Termine delle comunicazioni con il server.\n");
	send(fd,msg,strlen(msg),0);
	close(fd);
}

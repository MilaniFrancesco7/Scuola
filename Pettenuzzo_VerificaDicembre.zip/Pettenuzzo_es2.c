#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>

int main(){
  int clientSocket;
  char buffer[1024];
  struct sockaddr_in serverAddr;
  socklen_t addr_size;

  printf("Avvio del client.\n");
  /*creazione del socket*/
  clientSocket = socket(PF_INET, SOCK_STREAM, 0);
  /*configurazione parametri del server*/
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_port = htons(22);
  serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);

  /*si connette al server*/
  addr_size = sizeof serverAddr;
  connect(clientSocket, (struct sockaddr *) &serverAddr, addr_size);

  /*legge la risposta del server nel buffer per poi mostrarla a video*/
  recv(clientSocket, buffer,strlen("SSH-2.0-OpenSSH_7.2p2 Ubuntu-4ubuntu2.2"), 0);
  printf("Il server ha risposto : %s\n",buffer);
  printf("Termine del codice.\n");
  return 0;
}

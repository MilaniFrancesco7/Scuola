/*
 * Francesco Milani
 * 
 * 3AI
 * 201847
 * 
 * 

	Implementare una struct frazione che contiene denominatore, numeratore e segno.

	dopo aver creato la struct creare le funzioni:

    fractsum(ris, op1, op2)
    fractdiff(ris, op1, op2)
    fractmul(ris, op1, op2)
    fractinput(f)
    fractprint(f)

	e confezionare opportuno programma che usi tutto.

	Strutturare in due file, uno con il programma e uno con tutto quello che riguarda la struct

	consegna massima tre file (no zip)

	opzionale: anche il makefile

 * 
 * 
 */


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "Milani_Classialtraclasse.c"


int main()
{
	op op1=fractinput();
	
	fractprint(op1);
	
	op op2=fractinput();
	
	fractprint(op2);
	
	
	return 0;
}


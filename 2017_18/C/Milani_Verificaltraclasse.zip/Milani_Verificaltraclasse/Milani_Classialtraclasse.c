/* File che contiene le classi
 * 
 * 	fractsum(ris, op1, op2)
    fractdiff(ris, op1, op2)
    fractmul(ris, op1, op2)
    fractinput(f)
    fractprint(f)
 * 
 */


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>


	typedef struct sop
	{
		int num;
		int den;
		int segno;
		
	} op;
	
	
	op fractinput()
	{
		op op1;
		
		printf("Inserisci il numeratore della frazione: ");
		scanf("%d",&op1.num);
		
		printf("Inserisci il denominatore della frazione: ");
		scanf("%d",&op1.den);
		
		if(num>0 && den>0 || num<0 && den<0)
		{
			segno=1;
			
			if(num<0)
			{
				num=num*-1;
				den=den*-1;
			}
		}
		else
			segno=-1;
		
		return op1;
				
	}
	
	void fractprint(op op1)
	{
		printf("La frazione è: %d/%d\n",op1.num,op1.den);
	}

	

